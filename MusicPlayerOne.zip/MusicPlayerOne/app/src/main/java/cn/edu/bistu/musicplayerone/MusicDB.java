package cn.edu.bistu.musicplayerone;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MusicDB extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "MusicPlayer.db";
    private static final int DATABASE_VERSION = 1;
    private static String TABLE_NAME = "MusicList";
    private static String COLUMN_ID = "musicID";
    private static String COLUMN_MUSICNAME = "musicName";
    private static String COLUMN_SINGERNAME = "singerName";
    private static String COLUMN_ALBUMNAME = "albumName";
    private static String COLUMN_PATH = "path";
    private static String COLUMN_PICURL = "picUrl";
    private static String COLUMN_URL = "url";

    //构造方法
        public MusicDB(@Nullable Context context) {
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE "+TABLE_NAME+" ("+
                COLUMN_ID+" TEXT PRIMARY KEY,"+
                COLUMN_MUSICNAME+" TEXT,"+
                COLUMN_SINGERNAME+" TEXT,"+
                COLUMN_ALBUMNAME+" TEXT,"+
                COLUMN_PATH+" TEXT,"+
                COLUMN_PICURL+" text,"+
                COLUMN_URL+" TEXT);";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    /**
     * query
     * @return
     */
    Cursor readAllData(){
        String sql = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db!=null){
            cursor = db.rawQuery(sql,null);
        }
        return cursor;
    }

    /**
     * 查询数据库，返回ArrayList<MusicFile>集合
     * @return
     */
    public ArrayList<MusicFile> readLocalList(){
        ArrayList<MusicFile> MusicListLocal = new ArrayList<>();
        MusicDB db = new MusicDB(context.getApplicationContext());
        Cursor cursor1 = db.readAllData();
        while (cursor1.moveToNext()){
            MusicFile musicFile = new MusicFile();
            musicFile.setId(cursor1.getString(0));
            musicFile.setTitle(cursor1.getString(1));
            musicFile.setArtist(cursor1.getString(2));
            musicFile.setAlbum(cursor1.getString(3));
            musicFile.setPath(cursor1.getString(4));
            musicFile.setPicUrl(cursor1.getString(5));
            musicFile.setUrl(cursor1.getString(6));
            MusicListLocal.add(musicFile);
        }
        return MusicListLocal;
    }

    /**
     * 查询指定id的歌曲在数据库中的行号
     * @param id
     * @return
     */
    public int readPosition(String id){
        MusicDB db = new MusicDB(context.getApplicationContext());
        Cursor cursor = db.readAllData();
        int position = 0;//记录遍历数据库的行数
        while (cursor.moveToNext()){
            position++;
            if(cursor.getString(0).equals(id)){
                break;
            }
        }
        return position;
    }

    /**
     * insert
     * @param musicID
     * @param musicName
     * @param singerName
     * @param albumName
     * @param path
     * @param picUrl
     */
    public void addMusic(String musicID,String musicName,String singerName,String albumName,String path,String picUrl,String Url){
        SQLiteDatabase db = this. getWritableDatabase();//db为可写入对象
        ContentValues cv =new ContentValues();//一条记录
        cv.put(COLUMN_ID,musicID);
        cv.put(COLUMN_MUSICNAME,musicName);
        cv.put(COLUMN_SINGERNAME,singerName);
        cv.put(COLUMN_ALBUMNAME ,albumName);
        cv.put(COLUMN_PATH,path);
        cv.put(COLUMN_PICURL,picUrl);
        cv.put(COLUMN_URL,Url);
        long result = db.insert(TABLE_NAME,null,cv);
        if(result==-1){
            Toast.makeText(context,"本地添加失败!",Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(context,"本地添加成功!",Toast.LENGTH_SHORT).show();
    }

    /**
     * 判断歌曲是否存在数据库中
     * @param musicID
     * @return
     */
    public boolean exist(String musicID){
        SQLiteDatabase dbR = this.getReadableDatabase();
        String sql = "select * from " +TABLE_NAME+" where " +COLUMN_ID + "=" + musicID;
        Cursor cursor = dbR.rawQuery(sql,null);
        if(cursor.getCount()==0) {
            return false;
        }else {
            return true;
        }
    }

    /**
     * 按歌曲id在1数据库中删除对应歌曲
     * @param id
     */
    public void deleteMusic(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME," musicID=?",new String[]{id});
        if(result==-1){
            System.out.println("--------------数据库删除失败---------------");
        }
        else
            System.out.println("--------------数据库删除成功---------------");
    }


}
