package cn.edu.bistu.musicplayerone;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MyService extends IntentService {
    private Context context ;
    private final String TAG = "---MyService";
    private static String fileName = "";
    private static String filePath = "/MusicPlayerTJB/";
    private int FileLength;
    private int DownedFileLength = 0;
    private InputStream inputStream;
    private URLConnection connection;
    private String Url = "";
    private MusicDB db;

    public MyService() {
        super("hello");
    }

    public MyService(String name) {
        super("MyService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("MyService", "线程ID：" + Thread.currentThread(). getId());
        fileName = intent.getStringExtra("name")+intent.getStringExtra("id")+".mp3";
        Url = intent.getStringExtra("Url");
        System.out.println("MyService Url:"+Url);
        DownFile(Url);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        System.out.println("你好再见");
        Log.d(TAG, "onDestroy: 拜拜了");
        System.out.println("嗯嗯");
    }

    /**
     * 音乐的下载
     * @param urlString
     */
    private void DownFile(String urlString) {
        try {
            URL url = new URL(urlString);
            connection = url.openConnection();
            if (connection.getReadTimeout() == 5) {
                Log.i("---------->", "当前网络有问题");
            }
            inputStream = connection.getInputStream();

        } catch (MalformedURLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        /*
         * 文件的保存路径和和文件名其中Nobody.mp3是在手机SD卡上要保存的路径，如果不存在则新建
         */
        String savePAth = Environment.getExternalStorageDirectory() + filePath;
        System.out.println("+++++++++++++++++savePAth(文件路径):"+savePAth);
        File file1 = new File(savePAth);
        if (!file1.exists()) {
            file1.mkdir();
        }
        String savePathString = Environment.getExternalStorageDirectory() + filePath + fileName;
        System.out.println("+++++++++++++++++savePathString（文件路径+文件名）:"+savePathString);
        File file = new File(savePathString);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        /*
         * 向SD卡中写入文件,用Handle传递线程
         */
        Message message = new Message();
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rwd");
            randomAccessFile.setLength(FileLength);
            byte[] buf = new byte[1024 * 4];
            FileLength = connection.getContentLength();

            //下载过程
            int length = 0;
            while ((length = inputStream.read(buf)) != -1) {  //inputStream.read(Buffer)！= -1 表示从InputStream中读取一个数组的数据，如果返回-1 则表示数据读取完成
                randomAccessFile.write(buf, 0, length);
            }
            inputStream.close();
            randomAccessFile.close();
            Toast.makeText(this,"下载完成",Toast.LENGTH_SHORT).show();
            System.out.println("++++++++++++++intentService下载完成++++++++++++++++++++");

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
