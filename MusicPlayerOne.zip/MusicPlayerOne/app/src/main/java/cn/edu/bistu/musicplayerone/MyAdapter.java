package cn.edu.bistu.musicplayerone;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private Activity ac;
    private LayoutInflater mInflater;
    private ArrayList<HashMap<String, Object>> list;
    private ArrayList<MusicFile> MusicList;

    public MyAdapter(Context context,ArrayList<MusicFile> MusicList  ) {
        this.mInflater = LayoutInflater.from(context);
        this.MusicList = MusicList;
        System.out.println("MusicList.size:"+MusicList.size());
    }

    @Override
    public int getCount() {
        return MusicList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    static class ViewHolder{
        private TextView songName,singerName;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        MyAdapter.ViewHolder holder = new ViewHolder();
        if(view==null){
            view = mInflater.inflate(R.layout.holder_view,null);
            holder.songName = (TextView)view.findViewById(R.id.songName);
            holder.singerName = view.findViewById(R.id.singerName);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        holder.songName.setText(MusicList.get(i).getTitle());
        holder.singerName.setText(MusicList.get(i).getArtist());
        return view;
    }
}
