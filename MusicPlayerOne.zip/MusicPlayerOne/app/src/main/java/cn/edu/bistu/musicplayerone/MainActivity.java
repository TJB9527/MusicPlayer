package cn.edu.bistu.musicplayerone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "---MainActivity";
    static Context context ;
    private Button listBtn,localBtn;
    private ListView lv;
    private ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
    private HashMap<String, Object> map;
    private Handler handler;
    static ArrayList<MusicFile> MusicList = new ArrayList<>();
    private ArrayList<MusicFile> MusicListLocal = new ArrayList<>();
    public static final int REQUEST_CODE = 1;
    private MusicDB db;
    private RequestQueue requestQueue;
    private String Url = "";
    private MusicFile mFile;
    private boolean localFlag = false;
    private final int LIMIT = 66;

    public MainActivity(){
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = findViewById(R.id.lv);
        listBtn = findViewById(R.id.listBtn);
        localBtn = findViewById(R.id.localBtn);

        context = getApplicationContext();

        requestQueue = Volley.newRequestQueue(MainActivity.this);

        permission();

        //账号登录api，然后在线访问获取最近播放歌单的api，解析返回的每一首歌曲
        LoginApi();

        handler = new Handler(){
            @SuppressLint("HandlerLeak")
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if(msg.what==1){
                    LoadAdapter();
                }
                if(msg.what==2){
                    //播放
                    Intent intentListen = new Intent(MainActivity.this,ListenActivity.class);
                    intentListen.putExtra("id",mFile.getId());
                    startActivity(intentListen);
                }
            }
        };

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(localFlag){
                    mFile = MusicListLocal.get(i);
                    Url = "http://music.163.com/song/media/outer/url?id="+mFile.getId()+".mp3";
                    mFile.setUrl(Url);
                    Message message = new Message();
                    message.what = 2;
                    handler.sendMessage(message);
                }else{
                    mFile = MusicList.get(i);
                    Url = "http://music.163.com/song/media/outer/url?id="+mFile.getId()+".mp3";
                    if(Url==null){
                        Toast.makeText(MainActivity.this,"Url is null",Toast.LENGTH_SHORT).show();
                    }else {
                        mFile.setUrl(Url);
                        //添加到数据库
                        db = new MusicDB(MainActivity.this);
                        boolean flag = db.exist(mFile.getId());
                        if(!flag){   //如果本地（数据库）中没有当前点击歌曲，则下载后将歌曲保存到数据库并播放，否则直接进行播放
                            //下载
                            db.addMusic(mFile.getId(), mFile.getTitle(), mFile.getArtist(), mFile.getAlbum(), mFile.getPath(), mFile.getPicUrl(), mFile.getUrl());
                            Intent DownLoadService = new Intent(MainActivity.this,MyService.class);
                            DownLoadService.putExtra("id",mFile.getId());
                            DownLoadService.putExtra("name",mFile.getTitle());
                            DownLoadService.putExtra("artist",mFile.getArtist());
                            DownLoadService.putExtra("album",mFile.getAlbum());
                            DownLoadService.putExtra("path",mFile.getPath());
                            DownLoadService.putExtra("picUrl",mFile.getPicUrl());
                            DownLoadService.putExtra("Url",mFile.getUrl());
                            startService(DownLoadService);
                        }else {
                            Toast.makeText(MainActivity.this,"本地已存在歌曲<<"+mFile.getTitle()+">>，即将播放",Toast.LENGTH_SHORT).show();
                        }

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Thread.sleep(1 * 1000);  //线程休眠1秒执行（缓冲下载进度与播放进度之间的差距，以实现跳转即对当前歌曲播放）
                                    //TODO  todo somthing here
                                    Message message = new Message();
                                    message.what = 2;
                                    handler.sendMessage(message);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        }).start();
                    }
                }
            }
        });

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setItems(new String[]{"收藏","删除"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                break;
                            case 1:
                                MusicFile m = MusicListLocal.get(i);
                                db = new MusicDB(MainActivity.this);
                                db.deleteMusic(m.getId());

                                //删除本地歌曲文件
                                String pathDelete = Environment.getExternalStorageDirectory()+m.getPath();
                                System.out.println("-------------当前删除歌曲本地路径："+pathDelete+"------------------------");
                                File f = new File(pathDelete);
                                if(f.exists()&&f.isFile()){
                                    if(f.delete()){
                                        Toast.makeText(MainActivity.this,"本地歌曲文件"+m.getTitle()+"删除成功",Toast.LENGTH_SHORT).show();
                                        System.out.println("--------------本地歌曲文件"+m.getTitle()+"删除成功-------------------");
                                    }else {
                                        Toast.makeText(MainActivity.this,"本地歌曲文件"+m.getTitle()+"删除失败",Toast.LENGTH_SHORT).show();
                                        System.out.println("--------------本地歌曲文件"+m.getTitle()+"删除失败-------------------");
                                    }
                                }
                                //刷新本地歌单列表
                                MusicListLocal = db.readLocalList();
                                MyAdapter myAdapterLocal = new MyAdapter(MainActivity.this,MusicListLocal);
                                System.out.println("-----------本地歌单歌曲数量----------"+MusicListLocal.size());
                                myAdapterLocal.notifyDataSetChanged();
                                lv.setAdapter(myAdapterLocal);
                                break;
                            default:
                                break;
                        }
                    }
                });
                builder.create().show();
                return true;
            }
        });

        listBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                localFlag = false;
                LoadAdapter();
            }
        });

        localBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                localFlag = true;
                db = new MusicDB(MainActivity.this);
                MusicListLocal = db.readLocalList();
                MyAdapter myAdapterLocal = new MyAdapter(MainActivity.this,MusicListLocal);
                System.out.println("-----------本地歌单歌曲数量----------"+MusicListLocal.size());
                myAdapterLocal.notifyDataSetChanged();
                lv.setAdapter(myAdapterLocal);
            }
        });
    }

    /**
     * 动态获取权限
     */
    private void permission(){
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE)!=
                PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE);
        }
        else {
            Toast.makeText(MainActivity.this,"Is Granted!",Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CODE){
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                Toast.makeText(MainActivity.this,"Is Granted!",Toast.LENGTH_SHORT).show();
            }
            else {
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE);
            }
        }
    }

    /**
     * 加载适配器
     */
    public void LoadAdapter(){
        MyAdapter myAdapter = new MyAdapter(this,MusicList);
        lv.setAdapter(myAdapter);
    }

    /**
     * 账号登录api
     */
    public void LoginApi(){
        String url1 = "https://netease-cloud-music-api-three-lovat.vercel.app/login/cellphone?phone=18810002707&password=18810002707tjb";
        JsonObjectRequest jsonObjectRequestLogin = new JsonObjectRequest(Request.Method.GET, url1, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                System.out.println("第一次账号登录api成功");
                getSongsInfo();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this,"Login api error",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequestLogin);
    }

    /**
     * 在线访问api获取最近播放歌曲并解析
     */
    public void getSongsInfo(){
        String url2 = "https://netease-cloud-music-api-three-lovat.vercel.app/record/recent/song?limit="+LIMIT;
        JsonObjectRequest jsonObjectRequestMusic = new JsonObjectRequest(Request.Method.GET, url2, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONObject("data").getJSONArray("list");
                    System.out.println("jsonArray.length:"+jsonArray.length());
                    String songID = "";
                    for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = (JSONObject) jsonArray.get(i); //jsonObject对象是list数组中每一首歌的对象
                            songID = jsonObject.getJSONObject("data").getString("id");
                            String songName = jsonObject.getJSONObject("data").getString("name");

                            //获取歌手
                            JSONArray singerArray = jsonObject.getJSONObject("data").getJSONArray("ar");
                            JSONObject jsonObjectSinger = (JSONObject) singerArray.get(0);
                            String singerName = jsonObjectSinger.getString("name");

                            //获取专辑信息
                            JSONObject jsonObjectAlbum = jsonObject.getJSONObject("data").getJSONObject("al");
                            String albumName = jsonObjectAlbum.getString("name");
                            String picUrl  = jsonObjectAlbum.getString("picUrl");
                            String path = "/MusicPlayerTJB/"+songName+songID+".mp3";

                            MusicFile musicFile = new MusicFile(path,songName,singerName,albumName,picUrl,songID);
                            MusicList.add(musicFile);
                    }
                    System.out.println("--------------解析JSON完成1------------------------");
                    Message message = new Message();
                    message.what = 1;
                    handler.sendMessage(message);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this,"First api request error",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequestMusic);
    }
}