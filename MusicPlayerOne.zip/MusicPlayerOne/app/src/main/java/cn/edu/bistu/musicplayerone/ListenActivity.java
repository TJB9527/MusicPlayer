package cn.edu.bistu.musicplayerone;

import static cn.edu.bistu.musicplayerone.MainActivity.MusicList;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import com.squareup.picasso.Picasso;

public class ListenActivity extends AppCompatActivity implements MediaPlayer.OnCompletionListener{
    private ImageView BackArrow,TopMenu,Random,repeat,NextMusic,PerMusic,CoverView,TheBackGround;
    private FloatingActionButton Start;
    private SeekBar  seekBar;
    private TextView DurationTime,TotalTime,ArtistName_TheMedia,MusicName_TheMedia;
    static ArrayList<MusicFile> listSongs = new ArrayList<>();
    int position = -1;
    static Uri uri;
    static MediaPlayer mediaPlayer;
    private Handler handler =new Handler();
    private Thread playThread,prevThread,nextThread;
    static boolean randomBoolean = false,repeatBoolean=false;
    private MusicDB db;
    private String pathreal;

    @Override
    public void onCompletion(MediaPlayer mp) {  //在播放期间到达媒体源的末尾时调用
        try {
            NextBtnClicked();  //音乐播放完后自动进行下一曲的播放
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(mediaPlayer!=null){
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(pathreal);
                mediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(this);
        }
    }

    @Override
    protected void onResume() {  //onResume方法是Activity与用户交互时调用（Activity处于栈顶层），获取了用户焦点
        super.onResume();
        playThreadBtn();
        nextThreadBtn();
        prevThreadBtn();
    }


    /**
     * 上一曲子线程
     */
    private void prevThreadBtn() {
        prevThread=new Thread(){
            @Override
            public void run() {
                super.run();
                PerMusic.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            PreBtnClicked();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        };
        prevThread.start();
    }

    /**
     * 上一曲单击事件
     */
    private void PreBtnClicked() throws IOException {
        if(mediaPlayer.isPlaying()){
            mediaPlayer.stop();
            mediaPlayer.release();
            if(randomBoolean&&!repeatBoolean){  //如果当前模式是随机播放，随机切歌
                position=getRandom(listSongs.size()-1);
            }
            if(!repeatBoolean&&!randomBoolean){  //如果当前模式既不是随机播放也不是单曲循环（未设定播放模式），则按顺序切换至上一曲
                position=(position-1)%listSongs.size();
            }
            if(position<0){
                position=listSongs.size()-1;
            }
            pathreal = getRealPath(listSongs.get(position).getPath());
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(pathreal);
            mediaPlayer.prepare();
            metaData();
            MusicName_TheMedia.setText(listSongs.get(position).getTitle());
            ArtistName_TheMedia.setText(listSongs.get(position).getArtist());
            seekBar.setMax(mediaPlayer.getDuration()/1000);
            ListenActivity.this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if(mediaPlayer!=null){
                        int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosition);
                    }
                }
            });
            mediaPlayer.setOnCompletionListener(this);
            Start.setBackgroundResource(R.drawable.ic_baseline_pause_24);
            int durationTotal = (mediaPlayer.getDuration()/1000);
            TotalTime.setText(formattedTime(durationTotal));//设置进度条上歌曲播放时长（文本设置），区分于进度条的setMax
            mediaPlayer.start();
        }
        else {
            mediaPlayer.stop();
            mediaPlayer.release();
            if(randomBoolean&&!repeatBoolean){
                position=getRandom(listSongs.size()-1);
            }
            if(!repeatBoolean&&!randomBoolean){
                position=(position-1)%listSongs.size();
            }
            if(position<0)
                position=listSongs.size()-1;
            pathreal = getRealPath(listSongs.get(position).getPath());
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(pathreal);
            mediaPlayer.prepare();
            metaData();
            MusicName_TheMedia.setText(listSongs.get(position).getTitle());
            ArtistName_TheMedia.setText(listSongs.get(position).getArtist());
            seekBar.setMax(mediaPlayer.getDuration()/1000);
            ListenActivity.this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if(mediaPlayer!=null){
                        int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosition);
                    }
                }
            });
            mediaPlayer.setOnCompletionListener(this);
            Start.setBackgroundResource(R.drawable.ic_baseline_play_arrow_24);
        }
    }

    /**
     * 下一曲子线程
     */
    private void nextThreadBtn() {
        nextThread=new Thread(){
            @Override
            public void run() {
                super.run();
                NextMusic.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            NextBtnClicked();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        };
        nextThread.start();
    }

    /**
     * 下一曲单击事件
     * 核心：击下一曲时首先判断当前设定的播放模式（随机播放/单曲循环），根据两种模式进行对应歌曲的切换，并进行新的播放/暂停设置
     * 外层if/else的意义在于：点，如果当前歌曲正在播放，则切换后的歌曲保持播放状态，如果切换前的歌曲保持暂停状态，则切换后的歌曲也保持暂停状态
     */
    private void  NextBtnClicked() throws IOException {
        Log.e("Boolean","The Random is "+randomBoolean);
        Log.e("Boolean","The Shuffle is "+repeatBoolean);
        if(mediaPlayer.isPlaying()){
            mediaPlayer.stop();  //当前歌曲正在播放，则停止播放，释放当前播放歌曲mediaPlayer对象的资源
            mediaPlayer.release();
            if(randomBoolean&&!repeatBoolean){  //如果当前正处于随机播放模式，则随意切换到一首歌
                position=getRandom(listSongs.size()-1);
            }
            else if(!repeatBoolean){  //如果当前不处于单曲循环模式，则进行下一曲的切换
                position=(position+1)%listSongs.size();
            }
            pathreal = getRealPath(listSongs.get(position).getPath());
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(pathreal);
            mediaPlayer.prepare();
            metaData();
            MusicName_TheMedia.setText(listSongs.get(position).getTitle());
            ArtistName_TheMedia.setText(listSongs.get(position).getArtist());
            seekBar.setMax(mediaPlayer.getDuration()/1000);
            ListenActivity.this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if(mediaPlayer!=null){
                        int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosition);
                    }
                }
            });
            Start.setBackgroundResource(R.drawable.ic_baseline_pause_24);
            int durationTotal = (mediaPlayer.getDuration()/1000);
            TotalTime.setText(formattedTime(durationTotal));//设置进度条上歌曲播放时长（文本设置），区分于进度条的setMax
            mediaPlayer.start();
        }
        else {
            mediaPlayer.stop();
            mediaPlayer.release();
            if(randomBoolean&&!repeatBoolean){
                position=getRandom(listSongs.size()-1);
            }
            else if(!repeatBoolean){
                position=(position+1)%listSongs.size();
            }
            pathreal = getRealPath(listSongs.get(position).getPath());
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(pathreal);
            mediaPlayer.prepare();
            metaData();
            MusicName_TheMedia.setText(listSongs.get(position).getTitle());
            ArtistName_TheMedia.setText(listSongs.get(position).getArtist());
            seekBar.setMax(mediaPlayer.getDuration()/1000);
            ListenActivity.this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if(mediaPlayer!=null){
                        int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosition);
                    }
                }
            });
            Start.setBackgroundResource(R.drawable.ic_baseline_play_arrow_24);
        }
    }

    private int getRandom(int i) {
        Random random = new Random();
        return random.nextInt(i+1); //生成一个随机的int值，该值介于[0,n)的区间，包含0而不包含n
    }

    /**
     * 播放线程（内嵌了播放/暂停键点击事件、随机播放键点击事件、单曲循环键点击事件）
     * 播放/暂停键点击事件：主要实现对歌曲播放/暂停的切换
     * 后两者：主要实现单曲循环和随机播放标志位的改变（在上一曲下一曲线程中会受此约束）及图标的切换
     */
    private void playThreadBtn() {
        playThread=new Thread(){
            @Override
            public void run() {
                super.run();
                //播放点击事件
                Start.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        playPauseBtnClicked(); //播放/暂停键点击事件——实现播放/暂停切换
                    }
                });
                //随机播放点击事件
                Random.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Log.e("Boolean","Before The Random is "+randomBoolean);
                        if(randomBoolean){
                            randomBoolean=false;  //取消随机播放状态
                            Random.setImageResource(R.drawable.shuffle_24);
                            Log.e("Boolean","After The Random is "+randomBoolean);
                        }
                        else{
                            randomBoolean=true; //设置成随机播放状态
                            Random.setImageResource(R.drawable.ic_baseline_shuffle_24_on);
                            Log.e("Boolean","After The Random is "+randomBoolean);
                        }
                    }
                });
                //单曲循环点击事件
                repeat.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(repeatBoolean){
                            repeatBoolean=false;  //取消单曲循环状态
                            repeat.setImageResource(R.drawable.repeat_off);

                        }
                        else{
                            repeatBoolean=true;  //设置成单曲循环状态
                            repeat.setImageResource(R.drawable.repeat);
                        }
                    }
                });
            }
        };
        playThread.start();
    }

    /**
     * 播放/暂停切换
     */
    private void playPauseBtnClicked() {
        if(mediaPlayer.isPlaying()){
            Start.setImageResource(R.drawable.ic_baseline_play_arrow_24);  //设为（暂停状态）
            mediaPlayer.pause();
            seekBar.setMax(mediaPlayer.getDuration()/1000);
            ListenActivity.this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if(mediaPlayer!=null){
                        int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosition);  //设置当前暂停时进度
                    }
                }
            });
        }
        else
        {
            Start.setImageResource(R.drawable.ic_baseline_pause_24);  //设为（播放状态）
            mediaPlayer.start();
            seekBar.setMax(mediaPlayer.getDuration()/1000);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen);
        InitAll();
        try {
            getInterMethod();
        } catch (IOException e) {
            System.out.println("wwwwwwww------getInterMethod方法报异常-----wwwwwwwwwwwww");
            e.printStackTrace();
        }
        MusicName_TheMedia.setText(listSongs.get(position).getTitle());
        ArtistName_TheMedia.setText(listSongs.get(position).getArtist());
        mediaPlayer.setOnCompletionListener(this);   //回调函数：当流媒体播放完毕的时候回调

        ListenActivity.this.runOnUiThread(new Runnable(){
            @Override
            public void run() {
                if(mediaPlayer!=null){
                    int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                    seekBar.setProgress(mCurrentPosition);   //设置进度条实时播放进度
                    DurationTime.setText(formattedTime(mCurrentPosition)); //文本显示实时进度
                }
                handler.postDelayed(this,1000);//用于intent延迟跳转，定时刷新UI
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {   //通过该回调方法实现SeekBar的拖动事件
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {  //进度发生改变时会触发
                if(mediaPlayer!=null&&b){
                    mediaPlayer.seekTo(i*1000);//设置拖动后的播放进度
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    /**
     *对播放的时间进行格式化处理
     * @param mCurrentPosition
     * @return
     */
    private String formattedTime(int mCurrentPosition) {
        String totalout ="";
        String totalNew ="";
        String seconds = String.valueOf(mCurrentPosition%60);
        String minutes = String .valueOf(mCurrentPosition/60);
        totalout = minutes+":"+seconds;
        totalNew = minutes+":"+"0"+seconds;
        if(seconds.length()==1){
            return totalNew;
        }
        else return totalout;
    }

    /**
     * 将（播放/暂停键）设为播放状态；根据路径创建最新的mediaPlayer对象进行对音乐播放的控制；设置进度条最大播放时长
     */
    private void getInterMethod() throws IOException {
        String intentID = getIntent().getStringExtra("id");

        db = new MusicDB(ListenActivity.this);
        listSongs = db.readLocalList();
        int positionSQL = db.readPosition(intentID);
        position = positionSQL-1;
        System.out.println("------listSongs.length-----:"+listSongs.size());
        System.out.println("当前歌曲遍历到的在数据库中的位置:positionSQL="+positionSQL);
        System.out.println("打印数据库中本地歌曲:");
        for(MusicFile m : listSongs){
            System.out.println(m.getTitle());
        }

        String path = listSongs.get(position).getPath();
        pathreal = getRealPath(path);
        System.out.println("ListenActivity-------file.getPath():"+pathreal);

        if(listSongs !=null){
            Start.setImageResource(R.drawable.ic_baseline_pause_24);//（播放/暂停键）设为播放状态
        }

        //对每一首新的歌曲确保使用新的mediaPlayer对象进行播放的控制
        if(mediaPlayer!=null){
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(pathreal);
            mediaPlayer.prepare();
            mediaPlayer.start();
        }
        else{
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(pathreal);
            mediaPlayer.prepare();
            mediaPlayer.start();
        }

        Toast.makeText(ListenActivity.this,"mediaPlayer successfully build!",Toast.LENGTH_SHORT).show();

        seekBar.setMax(mediaPlayer.getDuration()/1000);//设置进度最大时间
        System.out.println("11111111111111-----mediaPlayer.getDuration:"+mediaPlayer.getDuration()/1000);
        int durationTotal = (mediaPlayer.getDuration()/1000);
        TotalTime.setText(formattedTime(durationTotal));//设置进度条上歌曲播放时长（文本设置），区分于进度条的setMax
        metaData();
    }

    /**
     *根据获得的歌曲的uri获取该歌曲其他信息（元数据）并填充界面控件（主要是对专辑图片动态切换动画效果的实现；其次文本设置最大时间）
     */
    private void metaData(){
        ImageView gredient = findViewById(R.id.coverArt);
        LinearLayout TheMainLayout = findViewById(R.id.TheMainLayout);
        gredient.setBackgroundResource(R.drawable.gradient);
        Picasso.get().load(listSongs.get(position).getPicUrl()).into(gredient);//
        TheMainLayout.setBackgroundResource(R.drawable.background);
        MusicName_TheMedia.setTextColor(Color.WHITE);
        ArtistName_TheMedia.setTextColor(Color.DKGRAY);
    }

    public String getRealPath(String path){
        File file = new File(Environment.getExternalStorageDirectory(),path);
        String pathreal = file.getPath();
        return pathreal;
    }

    private void InitAll(){
        BackArrow = findViewById(R.id.BackArrow);
        TopMenu=findViewById(R.id.TopMenu);
        Random=findViewById(R.id.Random);
        repeat=findViewById(R.id.repeat);
        NextMusic=findViewById(R.id.NextMusic);
        PerMusic=findViewById(R.id.PerMusic);
        Start=findViewById(R.id.Start);
        seekBar = findViewById(R.id.seekBar);
        DurationTime = findViewById(R.id.DurationTime);
        TotalTime = findViewById(R.id.TotalTime);
        CoverView  = findViewById(R.id.coverArt);
        ArtistName_TheMedia=findViewById(R.id.ArtistName_TheMedia);
        MusicName_TheMedia=findViewById(R.id.MusicName_TheMedia);
        NextMusic = findViewById(R.id.NextMusic);
        PerMusic=findViewById(R.id.PerMusic);
        TheBackGround=findViewById(R.id.TheBackGround);
        Random = findViewById(R.id.Random);
        repeat = findViewById(R.id.repeat);
    }
}